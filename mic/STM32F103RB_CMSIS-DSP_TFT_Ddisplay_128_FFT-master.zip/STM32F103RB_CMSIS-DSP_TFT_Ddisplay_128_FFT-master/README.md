### STM32F103RB使用CMSIS-DSP库在ALIENTEK MINISTM32 TFT 的代码上实现128点FFT显示 
B站演示地址：https://www.bilibili.com/video/BV1Kx411L7de/

#### 使用STM32F103RB芯片
![Devices](https://raw.githubusercontent.com/hxy513696765/STM32F103RB_CMSIS-DSP_TFT_Ddisplay_128_FFT/master/devices.png)

#### 使用CMSIS-DSP  Version 1.4.4
![DSPlib](https://raw.githubusercontent.com/hxy513696765/STM32F103RB_CMSIS-DSP_TFT_Ddisplay_128_FFT/master/DSPLib.png)
