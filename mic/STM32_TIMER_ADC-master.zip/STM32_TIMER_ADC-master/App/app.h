#pragma once

void init(void);

void setup(void);

void loop(void);
